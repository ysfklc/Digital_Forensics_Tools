Arsenal Image Mounter
Many Windows®-based disk image mounting solutions mount the contents of disk images as shares or partitions, rather than “complete” (a/k/a “physical” or “real”) disks, which limits their usefulness to digital forensics practitioners and others. Arsenal Image Mounter mounts the contents of disk images as complete disks in Windows. As far as Windows is concerned, the contents of disk images mounted by Arsenal Image Mounter are real SCSI disks, allowing users to benefit from disk-specific features like integration with Disk Manager, access to Volume Shadow Copies, launching virtual machines, and more.

End Users: If Arsenal Image Mounter is run without a license, it will run in "Free Mode" and provide core functionality. If Arsenal Image Mounter is licensed, it will run in "Professional Mode” with full functionality enabled.

Simple feature highlights:
[Free Mode] Mount raw, forensic, and virtual machine disk images as “real” disks on Windows
[Free Mode] Temporary write support with replayable delta files for all supported disk image formats
[Free Mode] Save "physically" mounted objects to various disk image formats
[Free Mode] Virtually mount optical images
[Free Mode] RAM disk creation
[Free Mode] Command-line interface (CLI) executables
[Free Mode] MBR injection, “fake” disk signatures, removable disk emulation, and much more

[Professional Mode] Effortlessly launch (and often login to) virtual machines
[Professional Mode] Volume Shadow Copy mounting with optional Windows NTFS driver bypass
[Professional Mode] Windows file system driver bypass support for disk image mounting
[Professional Mode] Virtually mount archives and directories

Developers: Arsenal Image Mounter source code, APIs, and executables are available for royalty-free use in open source projects. Commercial projects (and other projects not licensed under an AGPL v3 compatible license) that would like to use Arsenal Image Mounter source code, APIs, and/or executables must contact Arsenal (sales@ArsenalRecon.com) to obtain alternative licensing.

Detailed feature descriptions (Mount options):
Read only disk device - Mount the disk image as a read-only disk device. No write operations will be allowed.

Write temporary disk device - Mount the disk image as a writable disk device. Modifications will be written to a write-overlay differencing file and the original disk image will not be changed. Sometimes referred to as write-overlay or write-copy mode. (Note - required for launching virtual machines.) If you would like to choose an alternate location for the differencing file, check the "Specify an alternate differential file location" box. AIM will also ask for an alternate differential file location if the disk image you are about to mount is already open one or more times in this mode, or if writing to the same location as the disk image is not possible because the location in which the disk image is located is write protected.

Write original disk device - Mount the disk image as a writable disk device. Modifications will be written to the disk image. (Caution - this option modifies the original disk image.)

Windows file system driver bypass - Mount the disk image as a virtual read-only file system, using DiscUtils rather than Windows file system drivers. This mount option bypasses file system security and exposes NTFS metafiles. May also be useful to read files from images containing corrupted file systems.

Fake disk signature - Report a random disk signature to Windows. Useful if the disk image contains a zeroed-out disk signature or you are attempting to mount a duplicate disk signature. (Note - requires a valid MBR and partition table. Not compatible with GPT partitions or images without a partition table.)

Create “removable” disk device - Emulate the attachment of a USB thumb drive, which may facilitate the successful mounting of images containing partitions rather than complete disks or images without partition tables. (Caution - see relevant FAQ on our website for caveats.)

Detailed feature descriptions (Main screen and dropdown menus):
Mount VSCs - Mount all Volume Shadow Copies (VSCs) within a disk image with the option of either using the Windows NTFS driver or the DiscUtils NTFS driver (bypassing file system security and exposing NTFS metafiles) to parse VSC contents. Please note that AIM uses the Compact Disc File System (CDFS) when using the DiscUtils NTFS driver to mount VSCs, which results in last modified file system timestamps being displayed as both last modified and creation timestamps.

Launch VM – Launch a Hyper-V virtual machine using the selected AIM-mounted disk. The disk image should be mounted in write temporary mode before using this feature, which is designed to make booting the contents of a disk image in a virtual machine more efficient, reliable, and useful than other methods. The virtual machine is created with 2 CPUs, half of free host RAM (maximum of 4GB), two network adapters (not connected by default), one DVD-ROM (without any attached image) and the AIM-mounted disk as primary IDE HD. The Launch VM feature currently works (with full functionality) on Windows 8.1/10 (and Server 2012 R2/2016) x64 and requires that Hyper-V role be running on physical hardware, not within a virtual machine. Information from Microsoft about installing Hyper-V on Windows 10 is available at https://docs.microsoft.com/en-us/virtualization/hyper-v-on-windows/quick-start/enable-hyper-v. Arsenal's preference in terms of installing Hyper-V is the "Enable Hyper-V with CMD and DISM" method. If you are unsure whether Hyper-V is running, the output from "sc query HvService" at a command prompt can be helpful.

Some images can be difficult to boot directly into virtual machines, so after selecting the Launch VM feature AIM will offer assistance which includes scanning the disk image, disabling already unlocked BitLocker volumes, making repairs to dirty file systems, modifying relevant boot parameters, and injecting a small application known as AIM Virtual Machine Tools into virtual machines running Windows*1. AIM Virtual Machine Tools will automatically bypass the passwords of Windows accounts so that any password input will work (local, Microsoft (cloud), Active Directory, and Azure Active Directory accounts are supported) and will also provide accounts with administrative privileges. Please note that to access certain things in Windows like EFS objects and cached login credentials you will need to crack, and not bypass, account passwords*2. AIM Virtual Machine Tools can also open an administrative command prompt from the login screen. AIM Virtual Machine Tools will launch automatically on Windows XP and can be accessed via the “Ease of Access” icon on Windows Vista/7/8/8.1/10.

*1 A file named "AIM_MODIFIED.txt" will be placed on the root of each Windows volume in which AIM Virtual Machine Tools has made adjustments. These adjustments are temporary by design, based on "Write temporary..." mounting.

*2 In the case of Active Directory accounts, if a domain controller is available it is quite easy to set up a virtual network between it and the clients (all running in virtual machines launched by AIM), which will allow you to reset account passwords from the domain controller. Resetting passwords in this way will allow you access to previously inaccessible items on the clients such as EFS objects and cached login credentials.

Mount archive file –  Select zip, cab, wim, and tar (raw or gzip or bzip2 compressed) files to mount as virtual read-only drives (virtual CD-ROMs). Note that wim files often contain more than one image, so more than one virtual drive may appear. 

Mount directory – Select a directory to mount as a virtual read-only drive (virtual CD-ROM). Includes “Boot image” option to create a bootable CD/DVD or for use booting a virtual machine.

Save as new image file - Save a “physically” mounted object such as a disk image, including deltas, to a new raw (dd), vhd, vhdx, vdi, or vmdk file. Also supports saving virtually mounted objects such as archives and VSC contents to iso files. Some users may leverage this feature to effectively convert from one disk image (or other source) format to another, but please note that the source is saved as it currently appears to Windows - including (for example) injected MBRs, fake disk signatures, and other deltas.

Create RAM disk - Create one or more RAM disks as "real" disks containing NTFS file systems. RAM disks created by AIM can then be attached to virtual machines, saved to any of AIM's supported disk image formats, and more.

Detailed feature descriptions (CLI executables):
aim_cli.exe - Arsenal Image Mounter CLI is a .NET 4.0 tool that provides most of Arsenal Image Mounter’s functionality. The command “AIM_CLI /?” displays basic syntax for using Arsenal Image Mounter CLI.

aim_ll.exe - Arsenal Image Mounter Low Level is a tool that does not use .NET and provides more “low level” access to the Arsenal Image Mounter driver. The command “AIM_LL /?” displays basic syntax for using Arsenal Image Mounter Low Level.

FAQs:
Why is Arsenal Image Mounter different than other disk image mounting solutions?
Many disk image mounting solutions mount the contents of images in Windows as shares or partitions (rather than "complete" disks), which limits their usefulness. Arsenal Image Mounter is the first and only open source solution for mounting the contents of disk images as complete disks in Windows. We have also developed a significant amount of functionality that is particularly useful to the digital forensics and incident response community.

What are the requirements for running Arsenal Image Mounter?
Arsenal strongly recommends running Arsenal Image Mounter on Windows 8.1/10 (and Server 2012 R2/2016) x64. Most, but not all, AIM functionality is available on Vista/7/8 and Server 2012 x64 if .NET 4.5 is installed. Most, but not all, AIM functionality is available on both x64 and x86 versions of Vista/7/8 (and Server 2012 x64) when specifically using Arsenal Image Mounter CLI (if .NET 4.0 is installed) or Arsenal Image Mounter Low Level. Significant AIM functionality is unavailable in Windows versions prior to Vista - so while Arsenal Image Mounter CLI can be run on XP with .NET 4.0, and Arsenal Image Mounter Low Level can be run (theoretically) on 2000 onward, Arsenal does not support these older versions of Windows due to the loss of functionality.

How can I increase performance from disk images mounted by Arsenal Image Mounter?
Storing disk images on the fastest possible storage media is the most efficient way of increasing performance from disk images mounted by Arsenal Image Mounter. Here are benchmarks from launching a Windows 10 BitLockered disk image (184GB in size, E01 format) into a virtual machine with AIM (all benchmark times are from clicking Launch VM through Windows logon and seeing a user’s Desktop), which demonstrate the drastic differences in performance between disk images stored on hard disk drives (HDDs) and solid-state drives (SSDs):

Test 1: Mounted unlocked BitLockered disk image from internal HDD - 4-6 minutes 
Test 2: Mounted unlocked BitLockered disk image from internal SSD - 2-3 minutes
Test 3: Mounted fully decrypted BitLockered disk mage from internal HDD (full decryption took 40-45 minutes) - 3-4 minutes
Test 4: Mounted fully decrypted BitLockered disk image from internal SSD (full decryption took 10-15 minutes) - 1 minute

What file systems does Arsenal Image Mounter support?
When mounting disk images using the "Read only...", "Write temporary...", and "Write original..." mount options, Arsenal Image Mounter essentially "hands off" the contents of disk images to Windows as if they were real SCSI disks, so the file system drivers currently installed on Windows will be used as necessary. Arsenal has used NTFS, FAT32, ReFS, exFAT, HFS+, UFS, and EXT3 file systems contained within AIM-mounted disks successfully when the appropriate file system drivers were installed. AIM also supports bypassing Windows file system drivers and using DiscUtils file system drivers via the "Windows file system driver bypass" mount option.

What disk image formats does Arsenal Image Mounter support?
Raw (dd)
Advanced Forensics Format 4 (AFF4) 
EnCase (E01 and Ex01 if libewf is available)
Virtual Machine Disk Files (VHD, VDI, XVA, VMDK if discutils is available)

What do you mean when you use the phrase "disk images?"
When we use the phrase "disk images" we are using it loosely, in the sense that we are referring to images containing complete disks or partitions, whether they are in raw, virtual machine, or forensic formats.

Why are some files and folders inaccessible to me after mounting a disk image with Arsenal Image Mounter?
Arsenal Image Mounter passes the contents of disk images to Windows as if they were complete disks when using the "Read only...", "Write temporary...", and "Write original..." mount options. Once AIM has passed the contents of disk images mounted in these modes to Windows, the file system drivers you currently have installed take over and caveats like difficulty accessing protected files and folders may apply.

Is there a command-line interface version of Arsenal Image Mounter?
Yes – "Arsenal Image Mounter CLI" is a .NET 4.0 tool that provides most of Arsenal Image Mounter’s functionality. The command “AIM_CLI /?” displays basic syntax for using Arsenal Image Mounter CLI. We have also released "Arsenal Image Mounter Low Level" which does not use .NET and provides more low level access to the AIM driver. The command “AIM_LL /?” displays basic syntax for using Arsenal Image Mounter Low Level.

How can I or my organization contribute to Arsenal Image Mounter?
If Arsenal Image Mounter has become a valuable part of your toolkit, please let your colleagues in digital forensics know. We would also appreciate knowing how you use AIM and if you have any suggestions for future versions. If you or your organization have used AIM source code, APIs, and/or executables in open-source or commercial projects, please make sure you are complying with our licensing requirements. Commercial licensing of AIM source code, APIs, and/or executables helps us offset the cost of continued development, both in terms of Free and Professional Mode functionality.

What does "Create removable disk device" in the "Mount Options" screen do?
This function essentially emulates the attachment of a USB thumb drive. We have heard that it facilitates the mounting of images containing partitions rather than disks, even though Arsenal Image Mounter was designed to mount disks specifically. Characteristics (and limitations) of using this function include:

•    Windows (prior to Windows 10 Build 1703) will only identify and use the first partition on the image, even if the image contains more than one partition
•    SAN policies such as requiring new devices to be mounted offline do not apply
•    Drive letters are always assigned even if automatic drive letter assignment is turned off
•    Windows identifies and uses file systems even for single-volume images that have no partition table
•    Inability to interact with Volume Shadow Copies natively

Do I need an Internet connection for Arsenal Image Mounter licensing?
You only need an Internet connection for Arsenal Image Mounter when you initially enter your license code and when you renew your license. If you cannot connect to the Internet, please see "How can I license Arsenal Image Mounter on an offline workstation?" below.

How can I license Arsenal Image Mounter on an offline workstation?
If you want your air-gapped workstation properly licensed for Arsenal Image Mounter, please:

Open Arsenal Image Mounter and enter the license code you were given
Upon realizing that no Internet connection is available, Arsenal Image Mounter will save a “.LIC” file to your ProgramData\ArsenalRecon folder
On a workstation with Internet access, go to our Offline Activation page at https://www.softworkz.com/offline/offline.aspx and upload the “.LIC” file.
Finally, copy the CDM file you receive to your ProgramData\ArsenalRecon folder

Your air-gapped workstation is now ready to run Arsenal Image Mounter!

How can I mount and launch virtual machines from disk images containing BitLocker volumes?
When you use Arsenal Image Mounter to mount a disk image containing BitLocker volumes, Windows will recognize those volumes and either ask to unlock them with a key (assuming they were in a locked state) or it will begin real-time decryption without requiring any user input (assuming they were in a disabled or suspended state.) There are a variety of ways in which "BitLockered disk images" (how Arsenal refers to disk images containing one or more BitLocker volumes) can be launched into virtual machines. Here are some examples of workflows to launch BitLockered disk images into virtual machines:

This workflow is what we recommend if you would like maximum performance from the virtual machine:

1.) Use AIM to mount the disk image containing one or more BitLockered volumes in write-temporary mode
2.) Use Windows on your forensic workstation to unlock the BitLockered volume(s) (if the Windows dialog for unlocking goes away, double-click on the BitLockered volume(s) to bring it up again)
3.) Use Windows on your forensic workstation to fully decrypt* (via "manage-bde -off (Volume Letter:)" at a command prompt), not just unlock, the BitLockered volume(s)
4.) Use AIM’s Launch VM feature to launch a virtual machine
5.) Run AIM Virtual Machine Tools by selecting the Ease of Access icon and use password bypass, etc. as desired

* By fully decrypt, we are referring to turning BitLocker off (fully decrypting all the contents of the BitLocker volume) after you have mounted and unlocked the disk image with Arsenal Image Mounter in temporary-write mode. You can check on the status of a full BitLocker decryption by using "manage-bde -status Volume Letter:" at a command prompt. Unlocking (rather than fully decrypting) BitLocker only results in real-time decryption of the BitLocker volume contents as necessary, rather than full decryption.

This workflow is what we recommend for fastest access to the virtual machine (as there is no wait for full decryption):

1.) Use AIM to mount the disk image containing one or more BitLockered volumes in write-temporary mode
2.) Use Windows on your forensic workstation to unlock the BitLockered volume(s)
3.) Use AIM’s Launch VM feature to launch a virtual machine (when asked, allow AIM to disable* BitLocker encryption and inject AIM Virtual Machine Tools) 
4.) Run AIM Virtual Machine Tools by selecting the Ease of Access icon and use password bypass, etc. as desired

* By disable (a/k/a suspend), we are referring to exposing the BitLockered volume's encryption key in the clear (the equivalent of "manage-bde -protectors -disable (Volume Letter:)"), turning off any volume protection. 

This workflow we do not recommend, because AIM Virtual Machine Tools will not be injected and you will be on your own in terms of logging in to any Windows accounts:

1.) Use AIM to mount the disk image containing one or more BitLockered volumes in write-temporary mode
2.) Do not unlock BitLocker
3.) Use AIM’s Launch VM feature to launch a virtual machine (without allowing AIM to unlock and disable BitLocker encryption)

Can I use Arsenal Image Mounter to mount Volume Shadow Copies (VSCs) in Windows natively?
Yes, you can enable Arsenal Image Mounter's “Professional Mode” to access VSC mounting functionality and choose to mount the contents of VSCs with either the Windows or DiscUtils NTFS drivers, or you can leverage AIM’s "Free Mode" image mounting functionality along with other tools such as Eric Zimmerman's VSCMount at https://ericzimmerman.github.io/#!index.md or as described on David Cowen’s blog at http://www.hecfblog.com/2014/02/daily-blog-240-arsenal-image-mounter.html.

How can I release or attach my mouse from a virtual machine launched by AIM?
You can release your mouse from Hyper-V by using the keyboard shortcut CTRL-ALT-LEFT ARROW. In some cases you may find that clicking within the Hyper-V virtual machine does not immediately attach your mouse, but if you wait until the operating system within the virtual machine is ready for input (in other words, it's not busy!) you will then be able to attach your mouse. More keyboard shortcuts can be found at https://blogs.msdn.microsoft.com/virtual_pc_guy/2008/01/14/virtual-machine-connection-key-combinations-with-hyper-v.

Can I use Arsenal Image Mounter to decrypt full-disk and volume encryption within disk images?
Yes, Arsenal Image Mounter is used frequently for this purpose. You can read more about the general process on David Cowen’s blog at http://www.hecfblog.com/2014/03/daily-blog-263-decrypting-images-with.html. You can read more about the specific process involved with decrypting Apple FileVault encrypted volumes on Yogesh Khatri’s blog at http://www.swiftforensics.com/2013/03/decrypting-apple-filevault-full-volume.html.

Are you having trouble booting decrypted BitLocker volumes?
See Adam Bridge’s excellent blog post on modifying an NTFS volume’s Volume Boot Record (VBR) using Arsenal Image Mounter’s “Write temporary” mode at https://www.contextis.com/resources/blog/making-ntfs-volume-mountable-tinkering-vbr/.

How can I fix AIM’s drop-down menus from flying out beyond the GUI’s borders?
This behavior may be related to Windows Presentation Framework and “handedness.” Your handedness setting can be found by hitting Windows key+R, then pasting in “shell:::{80F3F1D5-FECA-45F3-BC32-752C152E456E}”. If your handedness setting is “Right-handed” you may want to change it to “Left-handed”.

Will using Hyper-V's "Enhanced Session Mode" cause any problems with Windows virtual machines?
Potentially, yes. We do not recommend using Hyper-V's Enhanced Session Mode (essentially using Remote Desktop to connect to the virtual machine) because unexpected policy issues may surface - for example, accounts may be prohibited from remote and password-less logons. If you are booting a virtual machine and see the Enhanced Session Mode dialog asking about screen resolution, just exit that dialog and you will be returned to direct console mode.

Is it possible to deploy Arsenal Image Mounter unattended?
To some extent, yes. We can provide customers with an installation package containing the Arsenal Image Mounter driver and the AIM CLI application, which can be installed silently depending on circumstances. While the installation will be silent in terms of Arsenal Image Mounter itself, it may not be silent in terms of Windows due to policy - for example, users may need to confirm that they trust drivers from Arsenal.

Is there an Application Programming Interface (API)?
Yes – Arsenal Image Mounter provides both .NET and non-.NET APIs. You can find these APIs on our GitHub page at https://github.com/ArsenalRecon/Arsenal-Image-Mounter/tree/master/API.

What programming languages have been used to build Arsenal Image Mounter?
Arsenal Image Mounter’s Storport miniport driver is written in C and its user mode API library is written in VB.NET, which facilitates easy integration with .NET 4.0 applications.

Where can I find the source code?
Arsenal Image Mounter source code can be found on GitHub at https://github.com/ArsenalRecon/Arsenal-Image-Mounter.

Use and License
We chose a dual-license for Arsenal Image Mounter (more specifically, Arsenal Image Mounter’s source code, APIs, and executables) to allow for royalty-free use in open source projects, but require financial support from commercial projects.

Arsenal Consulting, Inc. (d/b/a Arsenal Recon) retains the copyright to Arsenal Image Mounter, including the Arsenal Image Mounter source code, APIs, and executables, being made available under terms of the Affero General Public License v3. Arsenal Image Mounter source code, APIs, and executables may be used in projects that are licensed so as to be compatible with AGPL v3. If your project is not licensed under an AGPL v3 compatible license and you would like to use Arsenal Image Mounter source code, APIs, and/or executables, contact us (sales@ArsenalRecon.com) to obtain alternative licensing.

Contributors to Arsenal Image Mounter must sign the Arsenal Contributor Agreement (“ACA”). The ACA gives Arsenal and the contributor joint copyright interests in the source code.

